package com.example.beach_and_mountainbra;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String[] rentals = {"Beach Bike Rentals","Mountain Bike Rentals","Bike Rentals Website"};
        setListAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,rentals));

    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        switch (position)
        {
            case 0:
                startActivity(new Intent(MainActivity.this,Beach.class));
                break;
            case 1:
                startActivity(new Intent(MainActivity.this,Mountain.class));
                break;
            case 2:
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.campusbikeshop.com")));
                break;
        }
    }
}